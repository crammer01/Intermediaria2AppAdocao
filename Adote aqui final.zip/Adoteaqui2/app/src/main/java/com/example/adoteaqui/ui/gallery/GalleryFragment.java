package com.example.adoteaqui.ui.gallery;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.adoteaqui.R;

public class GalleryFragment extends Fragment implements View.OnClickListener {

    private Button btn_infoD1_id;
    private Button btn_infoD2_id;
    private Button btn_infoD3_id;
    private Button btn_infoD4_id;
    private Button btn_infoD5_id;
    private Button btn_infoD6_id;

    private GalleryViewModel galleryViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        galleryViewModel =
                ViewModelProviders.of(this).get(GalleryViewModel.class);
        View root = inflater.inflate(R.layout.fragment_dogs, container, false);

        btn_infoD1_id = root.findViewById(R.id.btn_infoD1_id);
        btn_infoD2_id = root.findViewById(R.id.btn_infoD2_id);
        btn_infoD3_id = root.findViewById(R.id.btn_infoD3_id);
        btn_infoD4_id = root.findViewById(R.id.btn_infoD4_id);
        btn_infoD5_id = root.findViewById(R.id.btn_infoD5_id);
        btn_infoD6_id = root.findViewById(R.id.btn_infoD6_id);

        btn_infoD1_id.setOnClickListener(this);
        btn_infoD1_id.setOnClickListener(this);
        btn_infoD1_id.setOnClickListener(this);
        btn_infoD1_id.setOnClickListener(this);
        btn_infoD1_id.setOnClickListener(this);
        btn_infoD1_id.setOnClickListener(this);

        return root;
    }

    @Override
    public void onClick(View v) {
        Toast.makeText(getActivity(), "Seu contato foi enviado ao doador, aguarde o contato!", Toast.LENGTH_LONG).show();
    }
}