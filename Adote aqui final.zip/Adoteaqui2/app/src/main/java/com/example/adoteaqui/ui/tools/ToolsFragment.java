package com.example.adoteaqui.ui.tools;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.adoteaqui.R;

public class ToolsFragment extends Fragment implements View.OnClickListener {

    private Button btn_infoP1_id;
    private Button btn_infoP2_id;
    private Button btn_infoP3_id;
    private Button btn_infoP4_id;
    private Button btn_infoP5_id;

    private ToolsViewModel toolsViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        toolsViewModel =
                ViewModelProviders.of(this).get(ToolsViewModel.class);
        View root = inflater.inflate(R.layout.fragment_passaros, container, false);

        btn_infoP1_id = root.findViewById(R.id.btn_infoB1_id);
        btn_infoP2_id = root.findViewById(R.id.btn_infoB2_id);
        btn_infoP3_id = root.findViewById(R.id.btn_infoB3_id);
        btn_infoP4_id = root.findViewById(R.id.btn_infoB4_id);
        btn_infoP5_id = root.findViewById(R.id.btn_infoB5_id);

        btn_infoP1_id.setOnClickListener(this);
        btn_infoP2_id.setOnClickListener(this);
        btn_infoP3_id.setOnClickListener(this);
        btn_infoP4_id.setOnClickListener(this);
        btn_infoP5_id.setOnClickListener(this);

        return root;
    }

    @Override
    public void onClick(View v) {
        Toast.makeText(getActivity(), "Seu contato foi enviado ao doador, aguarde o contato!", Toast.LENGTH_LONG).show();
    }
}